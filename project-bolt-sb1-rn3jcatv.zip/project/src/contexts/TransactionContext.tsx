import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Transaction, User } from '../types';

interface TransactionContextProps {
  transactions: Transaction[];
  members: User[];
  addTransaction: (transaction: Transaction) => void;
}

const TransactionContext = createContext<TransactionContextProps | undefined>(undefined);

interface TransactionProviderProps {
  children: ReactNode;
}

export const TransactionProvider: React.FC<TransactionProviderProps> = ({ children }) => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [members, setMembers] = useState<User[]>([]);
  
  // Load transactions from localStorage on initial load
  useEffect(() => {
    const storedTransactions = localStorage.getItem('covid19bank_transactions');
    if (storedTransactions) {
      try {
        const parsedTransactions = JSON.parse(storedTransactions);
        setTransactions(parsedTransactions);
      } catch (error) {
        console.error('Error parsing stored transactions:', error);
        localStorage.removeItem('covid19bank_transactions');
      }
    }
    
    const storedMembers = localStorage.getItem('covid19bank_members');
    if (storedMembers) {
      try {
        const parsedMembers = JSON.parse(storedMembers);
        setMembers(parsedMembers);
      } catch (error) {
        console.error('Error parsing stored members:', error);
        localStorage.removeItem('covid19bank_members');
      }
    }
  }, []);
  
  // Update localStorage whenever transactions or members change
  useEffect(() => {
    localStorage.setItem('covid19bank_transactions', JSON.stringify(transactions));
  }, [transactions]);
  
  useEffect(() => {
    localStorage.setItem('covid19bank_members', JSON.stringify(members));
  }, [members]);
  
  const addTransaction = (transaction: Transaction) => {
    setTransactions(prevTransactions => [...prevTransactions, transaction]);
    
    // Check if user exists in members list
    const userExists = members.some(member => member.id === transaction.userId);
    
    if (!userExists) {
      const newMember: User = {
        id: transaction.userId,
        name: transaction.userName,
        mobile: '' // We don't have access to mobile in this context, but it's required
      };
      
      setMembers(prevMembers => [...prevMembers, newMember]);
    }
  };
  
  return (
    <TransactionContext.Provider value={{ transactions, members, addTransaction }}>
      {children}
    </TransactionContext.Provider>
  );
};

export const useTransaction = (): TransactionContextProps => {
  const context = useContext(TransactionContext);
  if (context === undefined) {
    throw new Error('useTransaction must be used within a TransactionProvider');
  }
  return context;
};