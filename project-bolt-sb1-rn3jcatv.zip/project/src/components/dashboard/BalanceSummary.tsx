import React from 'react';
import { useTransaction } from '../../contexts/TransactionContext';
import { CreditCard, TrendingUp, TrendingDown, Wallet } from 'lucide-react';

const BalanceSummary: React.FC = () => {
  const { transactions } = useTransaction();
  
  // Calculate total deposits
  const totalDeposits = transactions
    .filter(t => t.type === 'deposit')
    .reduce((sum, t) => sum + t.amount, 0);
  
  // Calculate total withdrawals
  const totalWithdrawals = transactions
    .filter(t => t.type === 'withdrawal')
    .reduce((sum, t) => sum + t.amount, 0);
  
  // Calculate current balance
  const currentBalance = totalDeposits - totalWithdrawals;
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
      <div className="bg-white rounded-lg shadow-md p-4 border-l-4 border-green-500 transform transition-transform hover:scale-102 duration-300">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm text-gray-500 font-medium">Total Deposits</p>
            <h3 className="text-2xl font-bold text-gray-800">₹{totalDeposits.toLocaleString()}</h3>
          </div>
          <div className="bg-green-100 p-2 rounded-full">
            <TrendingUp className="text-green-500" size={24} />
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-4 border-l-4 border-red-500 transform transition-transform hover:scale-102 duration-300">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm text-gray-500 font-medium">Total Withdrawals</p>
            <h3 className="text-2xl font-bold text-gray-800">₹{totalWithdrawals.toLocaleString()}</h3>
          </div>
          <div className="bg-red-100 p-2 rounded-full">
            <TrendingDown className="text-red-500" size={24} />
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-4 border-l-4 border-blue-800 transform transition-transform hover:scale-102 duration-300">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm text-gray-500 font-medium">Current Balance</p>
            <h3 className={`text-2xl font-bold ${currentBalance >= 0 ? 'text-blue-800' : 'text-red-600'}`}>
              ₹{currentBalance.toLocaleString()}
            </h3>
          </div>
          <div className="bg-blue-100 p-2 rounded-full">
            <Wallet className="text-blue-800" size={24} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default BalanceSummary;