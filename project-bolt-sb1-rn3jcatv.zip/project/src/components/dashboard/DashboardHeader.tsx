import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { LogOut, User, CreditCard } from 'lucide-react';

const DashboardHeader: React.FC = () => {
  const { currentUser, logout } = useAuth();

  return (
    <div className="bg-white shadow-md rounded-lg p-4 mb-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between">
        <div className="flex items-center mb-4 md:mb-0">
          <div className="bg-blue-100 p-3 rounded-full mr-4">
            <User className="text-blue-800" size={24} />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-800">{currentUser?.name}</h2>
            <p className="text-sm text-gray-500 flex items-center">
              <CreditCard size={14} className="mr-1" /> 
              Member since {new Date().toLocaleDateString()}
            </p>
          </div>
        </div>
        <button
          onClick={logout}
          className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-4 rounded flex items-center justify-center transition-colors duration-300"
        >
          <LogOut size={16} className="mr-2" />
          Logout
        </button>
      </div>
    </div>
  );
};

export default DashboardHeader;