import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useTransaction } from '../../contexts/TransactionContext';
import { Transaction } from '../../types';
import { PlusCircle, MinusCircle, ChevronDown, Check } from 'lucide-react';

const TransactionForm: React.FC = () => {
  const { currentUser } = useAuth();
  const { addTransaction } = useTransaction();
  
  const [amount, setAmount] = useState('');
  const [type, setType] = useState<'deposit' | 'withdrawal'>('deposit');
  const [description, setDescription] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Clear success message after 3 seconds
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (success) {
      timer = setTimeout(() => {
        setSuccess('');
      }, 3000);
    }
    return () => clearTimeout(timer);
  }, [success]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    // Validate input
    if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) {
      setError('Please enter a valid amount');
      return;
    }
    
    setIsProcessing(true);
    
    // Create transaction object
    const transaction: Transaction = {
      id: Date.now().toString(),
      userId: currentUser?.id || '',
      userName: currentUser?.name || '',
      type,
      amount: Number(amount),
      description: description || `${type === 'deposit' ? 'Deposit' : 'Withdrawal'} transaction`,
      date: new Date().toISOString()
    };
    
    // Simulate processing
    setTimeout(() => {
      addTransaction(transaction);
      
      // Reset form
      setAmount('');
      setDescription('');
      setSuccess(`${type === 'deposit' ? 'Deposit' : 'Withdrawal'} of ₹${Number(amount).toLocaleString()} was successful!`);
      setIsProcessing(false);
    }, 800);
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <h2 className="text-xl font-bold text-gray-800 mb-4">New Transaction</h2>
      
      {error && (
        <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded flex items-center">
          <span className="mr-2">⚠️</span> {error}
        </div>
      )}
      
      {success && (
        <div className="mb-4 p-3 bg-green-100 border border-green-400 text-green-700 rounded flex items-center animate-fadeIn">
          <Check className="mr-2" size={18} /> {success}
        </div>
      )}
      
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-medium mb-2">
            Transaction Type
          </label>
          <div className="flex space-x-4">
            <button
              type="button"
              className={`flex-1 py-3 rounded-md border flex items-center justify-center transition-all ${
                type === 'deposit'
                  ? 'border-green-500 bg-green-50 text-green-700'
                  : 'border-gray-300 hover:bg-gray-50'
              }`}
              onClick={() => setType('deposit')}
            >
              <PlusCircle size={18} className={type === 'deposit' ? 'text-green-500 mr-2' : 'text-gray-400 mr-2'} />
              Deposit
            </button>
            <button
              type="button"
              className={`flex-1 py-3 rounded-md border flex items-center justify-center transition-all ${
                type === 'withdrawal'
                  ? 'border-red-500 bg-red-50 text-red-700'
                  : 'border-gray-300 hover:bg-gray-50'
              }`}
              onClick={() => setType('withdrawal')}
            >
              <MinusCircle size={18} className={type === 'withdrawal' ? 'text-red-500 mr-2' : 'text-gray-400 mr-2'} />
              Withdrawal
            </button>
          </div>
        </div>
        
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-medium mb-2" htmlFor="amount">
            Amount (₹)
          </label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">₹</span>
            <input
              className="shadow appearance-none border rounded w-full py-2 pl-8 pr-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500"
              id="amount"
              type="text"
              placeholder="Enter amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </div>
        </div>
        
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-medium mb-2" htmlFor="description">
            Description (Optional)
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500"
            id="description"
            type="text"
            placeholder="What's this transaction for?"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </div>
        
        <button
          type="submit"
          disabled={isProcessing}
          className={`w-full ${
            type === 'deposit' ? 'bg-green-600 hover:bg-green-700' : 'bg-blue-800 hover:bg-blue-900'
          } text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline transition-colors duration-300 flex items-center justify-center`}
        >
          {isProcessing ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Processing...
            </>
          ) : (
            <>
              {type === 'deposit' ? (
                <>
                  <PlusCircle size={18} className="mr-2" />
                  Make Deposit
                </>
              ) : (
                <>
                  <MinusCircle size={18} className="mr-2" />
                  Make Withdrawal
                </>
              )}
            </>
          )}
        </button>
      </form>
    </div>
  );
};

export default TransactionForm;