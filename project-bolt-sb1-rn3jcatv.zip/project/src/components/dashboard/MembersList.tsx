import React from 'react';
import { useTransaction } from '../../contexts/TransactionContext';
import { Users, TrendingUp, TrendingDown } from 'lucide-react';

const MembersList: React.FC = () => {
  const { transactions, members } = useTransaction();
  
  // Calculate contribution for each member
  const memberContributions = members.map(member => {
    const memberTransactions = transactions.filter(t => t.userId === member.id);
    
    const deposits = memberTransactions
      .filter(t => t.type === 'deposit')
      .reduce((sum, t) => sum + t.amount, 0);
      
    const withdrawals = memberTransactions
      .filter(t => t.type === 'withdrawal')
      .reduce((sum, t) => sum + t.amount, 0);
      
    const net = deposits - withdrawals;
    
    return {
      ...member,
      deposits,
      withdrawals,
      net
    };
  });
  
  return (
    <div className="bg-white rounded-lg shadow-md p-4 mb-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-gray-800 flex items-center">
          <Users className="mr-2 text-blue-800" size={20} />
          Group Members
        </h2>
        <span className="bg-blue-100 text-blue-800 py-1 px-3 rounded-full text-sm font-medium">
          {members.length} Members
        </span>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white">
          <thead>
            <tr className="bg-gray-100 text-gray-600 uppercase text-sm leading-normal">
              <th className="py-3 px-4 text-left">Member</th>
              <th className="py-3 px-4 text-right">
                <div className="flex items-center justify-end">
                  <TrendingUp size={14} className="mr-1 text-green-500" /> 
                  Deposits
                </div>
              </th>
              <th className="py-3 px-4 text-right">
                <div className="flex items-center justify-end">
                  <TrendingDown size={14} className="mr-1 text-red-500" /> 
                  Withdrawals
                </div>
              </th>
              <th className="py-3 px-4 text-right">Net Contribution</th>
            </tr>
          </thead>
          <tbody className="text-gray-600 text-sm">
            {memberContributions.map(member => (
              <tr key={member.id} className="border-b border-gray-200 hover:bg-gray-50">
                <td className="py-3 px-4 text-left whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-blue-100 flex items-center justify-center rounded-full mr-3">
                      {member.name.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <p className="font-medium">{member.name}</p>
                      <p className="text-xs text-gray-400">{member.mobile}</p>
                    </div>
                  </div>
                </td>
                <td className="py-3 px-4 text-right">
                  <span className="text-green-500 font-medium">₹{member.deposits.toLocaleString()}</span>
                </td>
                <td className="py-3 px-4 text-right">
                  <span className="text-red-500 font-medium">₹{member.withdrawals.toLocaleString()}</span>
                </td>
                <td className="py-3 px-4 text-right">
                  <span className={`font-medium ${member.net >= 0 ? 'text-blue-800' : 'text-red-600'}`}>
                    ₹{member.net.toLocaleString()}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default MembersList;