import React from 'react';
import { Home, Users, BarChart2, CreditCard, LogOut, Menu, X } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

interface SidebarProps {
  isOpen: boolean;
  toggleSidebar: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, toggleSidebar, activeTab, setActiveTab }) => {
  const { logout } = useAuth();
  
  const navItems = [
    { id: 'dashboard', icon: <Home size={20} />, label: 'Dashboard' },
    { id: 'transactions', icon: <CreditCard size={20} />, label: 'Transactions' },
    { id: 'members', icon: <Users size={20} />, label: 'Members' },
    { id: 'stats', icon: <BarChart2 size={20} />, label: 'Statistics' },
  ];
  
  const handleTabChange = (tabId: string) => {
    setActiveTab(tabId);
    if (window.innerWidth < 768) {
      toggleSidebar();
    }
  };
  
  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-20 md:hidden"
          onClick={toggleSidebar}
        ></div>
      )}
      
      {/* Sidebar */}
      <div 
        className={`fixed top-0 left-0 h-full bg-white shadow-lg z-30 w-64 transform transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        } md:static md:z-0`}
      >
        <div className="p-4 border-b flex items-center justify-between">
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-blue-800 flex items-center justify-center text-white">
              <CreditCard size={20} />
            </div>
            <h1 className="text-xl font-bold ml-2 text-gray-800">Covid-19 Bank</h1>
          </div>
          <button 
            className="md:hidden text-gray-500 hover:text-gray-700"
            onClick={toggleSidebar}
          >
            <X size={20} />
          </button>
        </div>
        
        <nav className="p-4">
          <ul className="space-y-2">
            {navItems.map((item) => (
              <li key={item.id}>
                <button
                  onClick={() => handleTabChange(item.id)}
                  className={`w-full flex items-center py-2 px-4 rounded-md transition-colors ${
                    activeTab === item.id
                      ? 'bg-blue-800 text-white'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <span className="mr-3">{item.icon}</span>
                  <span>{item.label}</span>
                </button>
              </li>
            ))}
          </ul>
          
          <div className="border-t mt-6 pt-4">
            <button
              onClick={logout}
              className="w-full flex items-center py-2 px-4 rounded-md text-red-600 hover:bg-red-50 transition-colors"
            >
              <LogOut size={20} className="mr-3" />
              <span>Logout</span>
            </button>
          </div>
        </nav>
      </div>
      
      {/* Mobile header with menu button */}
      <div className="md:hidden bg-white p-4 shadow-md flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center">
          <div className="w-8 h-8 rounded-full bg-blue-800 flex items-center justify-center text-white">
            <CreditCard size={16} />
          </div>
          <h1 className="text-lg font-bold ml-2 text-gray-800">Covid-19 Bank</h1>
        </div>
        <button 
          className="text-gray-500 hover:text-gray-700"
          onClick={toggleSidebar}
        >
          <Menu size={24} />
        </button>
      </div>
    </>
  );
};

export default Sidebar;