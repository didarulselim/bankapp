export interface User {
  id: string;
  name: string;
  mobile: string;
}

export interface Transaction {
  id: string;
  userId: string;
  userName: string;
  type: 'deposit' | 'withdrawal';
  amount: number;
  description: string;
  date: string;
}