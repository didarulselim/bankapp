import React, { useState } from 'react';
import Sidebar from '../components/layout/Sidebar';
import DashboardHeader from '../components/dashboard/DashboardHeader';
import BalanceSummary from '../components/dashboard/BalanceSummary';
import TransactionForm from '../components/dashboard/TransactionForm';
import TransactionHistory from '../components/dashboard/TransactionHistory';
import MembersList from '../components/dashboard/MembersList';

const Dashboard: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-gray-100">
      <Sidebar 
        isOpen={sidebarOpen} 
        toggleSidebar={toggleSidebar} 
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />
      
      <div className="flex-1 p-4 md:p-6 md:ml-64">
        {/* Main content based on active tab */}
        {activeTab === 'dashboard' && (
          <>
            <DashboardHeader />
            <BalanceSummary />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <TransactionForm />
              <div className="lg:mt-0">
                <TransactionHistory />
              </div>
            </div>
          </>
        )}
        
        {activeTab === 'transactions' && (
          <>
            <h1 className="text-2xl font-bold mb-6 text-gray-800">Transaction Management</h1>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-1">
                <TransactionForm />
              </div>
              <div className="lg:col-span-2">
                <TransactionHistory />
              </div>
            </div>
          </>
        )}
        
        {activeTab === 'members' && (
          <>
            <h1 className="text-2xl font-bold mb-6 text-gray-800">Group Members</h1>
            <MembersList />
          </>
        )}
        
        {activeTab === 'stats' && (
          <div className="bg-white rounded-lg shadow-md p-6">
            <h1 className="text-2xl font-bold mb-6 text-gray-800">Statistics & Analytics</h1>
            <div className="p-8 text-center bg-gray-50 rounded-lg">
              <p className="text-gray-500">Statistics view is under development.</p>
              <p className="text-gray-500 mt-2">Coming soon!</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;