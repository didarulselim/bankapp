import React from 'react';
import LoginForm from '../components/auth/LoginForm';
import { CreditCard } from 'lucide-react';

const Login: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-100 to-white flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md mx-auto mb-8 text-center">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-800 text-white mb-4">
          <CreditCard size={32} />
        </div>
        <h1 className="text-3xl font-bold text-blue-900">Covid-19 Bank</h1>
        <p className="text-gray-600 mt-2">Manage your group finances with ease</p>
      </div>
      
      <LoginForm />
      
      <div className="w-full max-w-md mx-auto mt-8 text-center">
        <p className="text-gray-500 text-sm">
          A secure way to track contributions and withdrawals for your group
        </p>
      </div>
    </div>
  );
};

export default Login;